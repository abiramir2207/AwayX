<cfoutput>

<cfscript>
    // base   = new components.base();
    // user   = new components.user.userManager();
    // qUsers = user.search();

    // writeDump( qUsers );
</cfscript>

</cfoutput>


<cfobject name="empObj" component="employee">
<cfobject name="mgrObj" component="manager">

<cfoutput>
    An employee earns #empObj.getPaid()#.<br>
    A manager earns #mgrObj.getPaid()#.<br>
</cfoutput>
